import "./App.css";
import { useState } from "react";
import Header from "./components/header";
import Note from "./pages/notes";
import AddNoteForm from "./pages/addNoteForm";
function App() {
   const [notes, setNotes] = useState([]);
   const [addItem, setAddItem] = useState(false);
   const handleSubmit = () => {
      setAddItem(!addItem);
   };
   const addNote = (note) => {
     setNotes(note);
   };
 
  return (
    <div>
      <Header handleSubmit={handleSubmit} />
      <div className='mainGrid'>
         <div className='column'>
             <Note notes={notes} addNote={addNote} />
         </div>
        {addItem && (
            <AddNoteForm
              addItem={addItem}
              setAddItem={setAddItem}
              notes={notes}
              setNotes={addNote}
            />
         )}
      </div>
    </div>
  );
}

export default App;